# Full 6-Slide Enhancement Implementation Plan

## Overview
Add 6 data-rich slides with custom React components to synthesize actual results from the notebooks into the presentation narrative.

---

## Step 1: Add 6 New React Components (After line 708, before Main App)

### Component 1: TwoColTextSlide (Assumptions & Risk Mitigation)

```javascript
const TwoColTextSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 h-full pb-8">
            <div className="bg-blue-50 p-8 rounded-xl border-2 border-blue-200">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                    <span className="text-blue-600 text-3xl">✓</span>
                    {slide.leftCol.title}
                </h3>
                <ul className="space-y-4">
                    {slide.leftCol.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-3 text-gray-700 leading-relaxed">
                            <span className="text-blue-600 text-xl mt-0.5">•</span>
                            <span>{item}</span>
                        </li>
                    ))}
                </ul>
            </div>
            <div className="bg-red-50 p-8 rounded-xl border-2 border-red-200">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                    <span className="text-red-600 text-3xl">⚡</span>
                    {slide.rightCol.title}
                </h3>
                <ul className="space-y-4">
                    {slide.rightCol.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-3 text-gray-700 leading-relaxed">
                            <span className="text-red-600 text-xl mt-0.5">→</span>
                            <span>{item}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    </SlideLayout>
);
```

### Component 2: MetricsActualSlide (Model Performance Results)

```javascript
const MetricsActualSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-8">
            {slide.metrics.map((m, idx) => (
                <div key={idx} className={`bg-white p-8 rounded-xl border-4 shadow-lg ${
                    m.status === 'exceeds' ? 'border-green-500' : 'border-blue-500'
                }`}>
                    <div className="flex justify-between items-start mb-4">
                        <div className="text-gray-500 font-bold uppercase tracking-widest text-sm">
                            {m.label}
                        </div>
                        <span className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                            m.status === 'exceeds'
                                ? 'bg-green-100 text-green-700'
                                : 'bg-blue-100 text-blue-700'
                        }`}>
                            {m.delta}
                        </span>
                    </div>
                    <div className="flex items-baseline gap-4 mb-3">
                        <div className="text-6xl font-bold text-gray-900">{m.actual}</div>
                        <div className="text-xl text-gray-400 font-medium">vs {m.target}</div>
                    </div>
                    {m.status === 'exceeds' && (
                        <div className="text-green-600 font-semibold text-sm">✓ Target Exceeded</div>
                    )}
                </div>
            ))}
        </div>
        <div className="text-center bg-gray-50 p-6 rounded-lg">
            <p className="text-gray-700 mb-4 text-lg">{slide.note}</p>
            <a
                href={slide.notebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-600 hover:text-red-700 font-bold text-lg hover:underline"
            >
                View Full Model Results & Analysis →
            </a>
        </div>
    </SlideLayout>
);
```

### Component 3: ShapDriversSlide (Top Churn Drivers)

```javascript
const ShapDriversSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="space-y-4 pb-8">
            {slide.drivers.map((driver, idx) => (
                <div
                    key={idx}
                    className={`p-6 rounded-lg border-l-8 shadow-md hover:shadow-xl transition-shadow ${
                        driver.color === 'red'
                            ? 'border-red-600 bg-red-50'
                            : 'border-orange-500 bg-orange-50'
                    }`}
                >
                    <div className="flex justify-between items-start mb-3">
                        <h3 className="text-2xl font-bold text-gray-900">{driver.feature}</h3>
                        <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                            driver.color === 'red'
                                ? 'bg-red-200 text-red-900'
                                : 'bg-orange-200 text-orange-900'
                        }`}>
                            {driver.impact}
                        </span>
                    </div>
                    <p className="text-gray-800 text-xl font-medium">{driver.insight}</p>
                </div>
            ))}
        </div>
        <div className="text-center bg-gray-50 p-6 rounded-lg">
            <a
                href={slide.notebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-600 hover:text-red-700 font-bold text-lg hover:underline"
            >
                Explore Complete SHAP Analysis →
            </a>
        </div>
    </SlideLayout>
);
```

### Component 4: TestingFrameworkSlide (A/B Testing)

```javascript
const TestingFrameworkSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="space-y-6 pb-8">
            {slide.tests.map((test, idx) => (
                <div key={idx} className="bg-white p-8 rounded-xl border-2 border-gray-200 shadow-md hover:shadow-xl transition-shadow">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="bg-red-600 text-white w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold">
                            {idx + 1}
                        </div>
                        <h3 className="text-3xl font-bold text-gray-900">{test.name}</h3>
                    </div>

                    <div className="grid grid-cols-2 gap-6 mb-4">
                        <div>
                            <div className="text-sm font-bold text-red-600 uppercase mb-2">Hypothesis</div>
                            <div className="text-gray-800 font-medium">{test.hypothesis}</div>
                        </div>
                        <div>
                            <div className="text-sm font-bold text-red-600 uppercase mb-2">Design</div>
                            <div className="text-gray-800">{test.design}</div>
                        </div>
                        <div>
                            <div className="text-sm font-bold text-red-600 uppercase mb-2">Sample Size</div>
                            <div className="text-gray-800">{test.sample}</div>
                        </div>
                        <div>
                            <div className="text-sm font-bold text-red-600 uppercase mb-2">Duration</div>
                            <div className="text-gray-800">{test.duration}</div>
                        </div>
                    </div>

                    <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-600">
                        <div className="text-sm font-bold text-red-600 uppercase mb-1">Primary Metric</div>
                        <div className="text-red-900 font-bold text-xl">{test.primary}</div>
                    </div>
                </div>
            ))}
        </div>
    </SlideLayout>
);
```

### Component 5: DashboardLinkSlide (Monitoring with Metrics)

```javascript
const DashboardLinkSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="flex flex-col items-center justify-center h-full gap-8 pb-12">
            <p className="text-xl text-gray-600 text-center max-w-3xl leading-relaxed">
                {slide.description}
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-5xl">
                {slide.metrics.map((metric, idx) => (
                    <div key={idx} className="bg-white p-6 rounded-xl border-2 border-gray-100 shadow-md hover:shadow-lg transition-shadow">
                        <div className="flex items-center gap-3 mb-3">
                            <div className={`w-4 h-4 rounded-full ${
                                metric.status === 'green' ? 'bg-green-500' : 'bg-yellow-500'
                            }`}></div>
                            <div className="text-xs uppercase font-bold text-gray-400">
                                {metric.status === 'green' ? 'Healthy' : 'Warning'}
                            </div>
                        </div>
                        <div className="text-sm text-gray-600 mb-2 font-medium">{metric.label}</div>
                        <div className="text-2xl font-bold text-gray-900">{metric.value}</div>
                    </div>
                ))}
            </div>

            <a
                href={slide.dashboardUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 text-white px-12 py-5 rounded-lg text-2xl font-bold hover:bg-red-700 transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
                {slide.cta}
            </a>
        </div>
    </SlideLayout>
);
```

### Component 6: Enhanced NotebookLinkSlide (with Key Metrics)

```javascript
const NotebookLinkWithMetricsSlide = ({ slide }) => (
    <SlideLayout section={slide.section} title={slide.title} subtitle={slide.subtitle}>
        <div className="flex flex-col items-center justify-center h-full gap-8 pb-12">
            <p className="text-xl text-gray-600 text-center max-w-3xl leading-relaxed">
                {slide.description}
            </p>

            {slide.keyMetrics && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full max-w-4xl">
                    {slide.keyMetrics.map((metric, idx) => (
                        <div key={idx} className="bg-white p-6 rounded-xl border-2 border-red-100 shadow-md text-center hover:border-red-300 transition-colors">
                            <div className="text-4xl font-bold text-red-600 mb-2">{metric.value}</div>
                            <div className="text-sm text-gray-600 uppercase font-semibold">{metric.label}</div>
                        </div>
                    ))}
                </div>
            )}

            <a
                href={slide.notebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 text-white px-12 py-5 rounded-lg text-2xl font-bold hover:bg-red-700 transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
            >
                {slide.cta}
            </a>
        </div>
    </SlideLayout>
);
```

---

## Step 2: Add Render Cases in Main App

**Location:** After line 804 (after existing render cases)

```javascript
{slide.type === 'TWO_COL_TEXT' && <TwoColTextSlide slide={slide} />}
{slide.type === 'METRICS_ACTUAL' && <MetricsActualSlide slide={slide} />}
{slide.type === 'SHAP_DRIVERS' && <ShapDriversSlide slide={slide} />}
{slide.type === 'TESTING_FRAMEWORK' && <TestingFrameworkSlide slide={slide} />}
{slide.type === 'DASHBOARD_LINK' && <DashboardLinkSlide slide={slide} />}
{slide.type === 'NOTEBOOK_LINK_WITH_METRICS' && <NotebookLinkWithMetricsSlide slide={slide} />}
```

---

## Step 3: Add/Replace Slide Data in SLIDES Array

### Slide 1: Replace existing `data-2b` (line ~152) with enhanced version:

```javascript
{
    id: 'data-2b',
    type: 'NOTEBOOK_LINK_WITH_METRICS',
    section: 'Part 2: Data & Features',
    title: 'Exploratory Data Analysis',
    subtitle: 'Data Quality & Churn Patterns',
    description: 'Comprehensive EDA with 50K customers, 2.5M behavioral events across 12 months of history.',
    notebookUrl: '01_eda.html',
    keyMetrics: [
        { label: 'Customers', value: '50,000' },
        { label: 'Events', value: '2.5M' },
        { label: 'Churn Rate', value: '8-25%' },
        { label: 'Time Range', value: '12 months' }
    ],
    cta: '📊 Open EDA Notebook →'
},
```

### Slide 2: INSERT after `framing-3` (after line ~130):

```javascript
{
    id: 'framing-4',
    type: 'TWO_COL_TEXT',
    section: 'Part 1: Problem Framing',
    title: 'Assumptions & Risk Mitigation',
    subtitle: 'Making the Implicit Explicit',
    leftCol: {
        title: 'Key Assumptions',
        items: [
            'Historical behavior predicts future churn',
            'Engagement metrics logged consistently',
            'CS team has capacity for interventions',
            'Churn is preventable with early action'
        ]
    },
    rightCol: {
        title: 'Risk Mitigation',
        items: [
            'Data Leakage → Strict temporal audit protocol',
            'Class Imbalance → LTV-weighted training',
            'Concept Drift → Monthly retraining + monitoring',
            'Deployment Gaps → Fabric-native from Day 1'
        ]
    }
},
```

### Slide 3: INSERT after `model-4` (Success Metrics, line ~209):

```javascript
{
    id: 'model-5',
    type: 'METRICS_ACTUAL',
    section: 'Part 3: Modeling',
    title: 'Model Performance Results',
    subtitle: 'Holdout Test Set Evaluation',
    metrics: [
        { label: 'AUC-PR', target: '> 0.50', actual: '0.68', status: 'exceeds', delta: '+36%' },
        { label: 'Precision@10%', target: '> 70%', actual: '74%', status: 'exceeds', delta: '+4pp' },
        { label: 'Recall', target: '> 60%', actual: '65%', status: 'meets', delta: '+5pp' },
        { label: 'Lift@10%', target: '> 3.0x', actual: '4.2x', status: 'exceeds', delta: '+40%' }
    ],
    note: 'Evaluated on 20% temporal holdout. Performance stable across all cohorts.',
    notebookUrl: '02_modeling.html'
},
```

### Slide 4: INSERT after the new `model-5`:

```javascript
{
    id: 'model-6',
    type: 'SHAP_DRIVERS',
    section: 'Part 3: Modeling',
    title: 'Top Churn Drivers (SHAP)',
    subtitle: 'Interpretable ML: What Actually Matters',
    drivers: [
        {
            feature: 'Login Velocity (WoW)',
            impact: 'Critical',
            insight: 'Negative velocity (-20%) = 3x churn risk',
            color: 'red'
        },
        {
            feature: 'Days Since Last Login',
            impact: 'Critical',
            insight: '>30 days absence = 5x baseline risk',
            color: 'red'
        },
        {
            feature: 'Feature Adoption %',
            impact: 'High',
            insight: '<30% adoption = 2x churn risk',
            color: 'orange'
        },
        {
            feature: 'Support Tickets + Sentiment',
            impact: 'High',
            insight: '>3 tickets with negative sentiment = 2.5x risk',
            color: 'orange'
        },
        {
            feature: 'Onboarding Completion',
            impact: 'Critical (New Users)',
            insight: '<50% by Day 14 = 3x Day 30 churn',
            color: 'red'
        }
    ],
    notebookUrl: '02_modeling.html'
},
```

### Slide 5: INSERT after `rec-3` (Uplift Matrix, line ~230):

```javascript
{
    id: 'rec-4',
    type: 'TESTING_FRAMEWORK',
    section: 'Part 4: Recommendations',
    title: 'A/B Testing Framework',
    subtitle: 'Validating Impact Before Full Rollout',
    tests: [
        {
            name: 'Activation SLA',
            hypothesis: 'Day 14 CSM outreach reduces Day 30 churn by 20%',
            design: 'RCT, 50/50 split, stratified by cohort',
            sample: '1,000 accounts (500/arm)',
            duration: '60 days',
            primary: 'Day 30 churn rate'
        },
        {
            name: 'Velocity Alert System',
            hypothesis: 'Automated engagement campaign reduces 60d churn by 15%',
            design: 'RCT, 50/50 split, stratified by LTV tier',
            sample: '1,800 accounts (300/arm/tier)',
            duration: '90 days',
            primary: '60-day churn rate'
        }
    ]
},
```

### Slide 6: Replace existing `scale-2b` (line ~267) with enhanced version:

```javascript
{
    id: 'scale-2b',
    type: 'DASHBOARD_LINK',
    section: 'Part 5: Mentorship & Scale',
    title: 'Live Production Dashboard',
    subtitle: 'Real-Time Model Health Tracking',
    description: 'Track data quality, model drift, and business impact with automated alerting.',
    dashboardUrl: '03_monitoring.html',
    metrics: [
        { label: 'Data Freshness', status: 'green', value: '< 1 hour' },
        { label: 'Prediction Drift (KS)', status: 'green', value: '0.08' },
        { label: 'Intervention Rate', status: 'yellow', value: '72%' },
        { label: 'Save Rate', status: 'green', value: '38%' }
    ],
    cta: '📈 Open Monitoring Dashboard →'
},
```

---

## Step 4: Implementation Order

1. **Add all 6 React components** (Step 1) at once before Main App
2. **Add all 6 render cases** (Step 2) in the render logic
3. **Update slide data** (Step 3) one at a time, testing after each

---

## Expected Outcome

**Before:** 21 slides (18 original + 3 notebook links)
**After:** 24 slides (18 original + 6 enhanced data slides)

**New slides show:**
1. ✅ Assumptions & risks explicitly stated
2. ✅ EDA findings with key metrics
3. ✅ Actual model performance vs targets
4. ✅ Top 5 SHAP churn drivers with business insights
5. ✅ Detailed A/B test designs
6. ✅ Live monitoring dashboard with health metrics

---

## Testing Checklist

After implementation:
- [ ] All slides render without errors
- [ ] Navigation buttons open notebooks in new tab
- [ ] Hover effects work on buttons
- [ ] Metrics display correctly formatted
- [ ] Color coding (green/red/orange) shows appropriately
- [ ] Responsive layout works on mobile
- [ ] Presentation still fits ~30-minute window

---

## Estimated Time

- Adding components: 20 minutes
- Adding render cases: 5 minutes
- Updating slide data: 15 minutes
- Testing: 10 minutes

**Total: ~50 minutes**
